from turtle import Turtle
FONT = ("Courier", 15, "bold")
FONT_END = ("Courier", 25, "bold")
ALIGNMENT = "center"
MOVE = False


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.level = 1
        self.penup()
        self.hideturtle()
        self.speed(10)
        self.goto(-220, 270)
        self.write(f"Level: {self.level}", MOVE, ALIGNMENT, FONT)

    def increment_score(self):
        self.clear()
        self.level += 1
        self.write(f"Level: {self.level}", MOVE, ALIGNMENT, FONT)


    def game_over(self):
        super().__init__()
        self.penup()
        self.goto(0, 260)
        self.write("GAME OVER", MOVE, ALIGNMENT, FONT_END)
        self.hideturtle()



