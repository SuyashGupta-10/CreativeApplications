from turtle import Turtle
import random

COLORS = ["red", "orange", "cyan", "pink", "blue", "purple"]


class CarManager(Turtle):
    def __init__(self):
        super().__init__()
        self.all_cars = []
        self.hideturtle()

    def add_car(self):
        n = random.randint(1,8)
        if n == 1 or n == 2:
            new_car = Turtle("square")
            new_car.penup()
            new_car.speed("fastest")
            new_car.setheading(180)
            new_car.color(random.choice(COLORS))
            new_car.shapesize(stretch_wid=1, stretch_len=2)
            random_y = random.randint(-250, 250)
            new_car.goto(300, random_y)
            self.all_cars.append(new_car)

    def move_cars(self, distance):
        for car in self.all_cars:
            car.forward(distance)





        
        


