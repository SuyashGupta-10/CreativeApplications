import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 5

screen = Screen()
player = Player()
scoreboard = Scoreboard()
car_manager = CarManager()
screen.setup(width=600, height=600)
screen.title("Turtle Crossing")
screen.listen()
screen.onkeypress(player.motion, "Up")
screen.tracer(0)


def game_function():
    game_is_on = True
    while game_is_on:
        time.sleep(0.1)
        screen.update()

        car_manager.add_car()
        car_manager.move_cars(STARTING_MOVE_DISTANCE + (scoreboard.level - 1) * MOVE_INCREMENT)

        for car in car_manager.all_cars:
            if car.distance(player) < 20:
                game_is_on = False
                scoreboard.game_over()

        if player.ycor() > 280:
            scoreboard.increment_score()
            game_is_on = False
            player.goto(0, -280)
            game_function()

game_function()

screen.exitonclick()
